#include "app.h" 
#include "Tracer.h" 
#include "Clock.h"  
using namespace ev3api;

Tracer tracer;  
Clock clock;
bool isDoneSection = false;
bool isInitializedClock = false;

uint32_t currentTime = 0;
uint32_t lastTime = 0;

uint8_t stateFlag = 0;
// stateFlag :
// 0 : initial state
// 1 : is done round
// 2 : is done open hand
// 3 : 
// 4 : 
// 5 : 
// 6 : 

static int DulationTimes[] = {0, 3000, 4000, 5000};

bool CheckTime(uint32_t now, uint32_t last, uint32_t dulation);

void tracer_task(intptr_t exinf) {
  currentTime = clock.now();

  switch (stateFlag)
  {
  case 0:
    isDoneSection = CheckTime(currentTime, lastTime, DulationTimes[0]);

    if (!isDoneSection) {
      break;
    }

    lastTime = clock.now();
    stateFlag++;
    tracer.round(100, 10);

    break;

  case 1:
    isDoneSection = CheckTime(currentTime, lastTime, DulationTimes[1]);

    if (!isDoneSection) {
      break;
    }

    lastTime = clock.now();
    stateFlag++;
    tracer.round(0, 0);

    break;

  case 2:
    break;
  
  case 3:
    break;
  
  case 4:
    break;
  
  case 5:
    break;
  }
  
  ext_tsk();
}

bool CheckTime(uint32_t now, uint32_t last, uint32_t dulation) {
  if((now - last) >= dulation) {
    return true;
  } else {
    return false;
  }
}

void InitializeClock () {
  clock.reset();
  currentTime = lastTime = clock.now();
  isInitializedClock = true;
}

void main_task(intptr_t unused) {
  const uint32_t duration = 100;
  tracer.init();
  sta_cyc(TRACER_CYC); 

  if (!isInitializedClock) {
    InitializeClock();
  }
  
  while (!ev3_button_is_pressed(LEFT_BUTTON)) { 
      clock.sleep(duration);   
  }

  stp_cyc(TRACER_CYC); 
  tracer.terminate();
  ext_tsk(); 
}