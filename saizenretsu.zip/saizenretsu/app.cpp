#include "app.h" 
#include "Tracer.h" 
#include "Clock.h"  
using namespace ev3api;

Tracer tracer;  
Clock clock;
bool isDoneSection1 = false;
bool isInitializedClock = false;
uint32_t currentTime = 0;
uint32_t lastTime = 0;

bool CheckTime(uint32_t now, uint32_t last, uint32_t dulation);

void tracer_task(intptr_t exinf) {
  currentTime = clock.now();
  isDoneSection1 = CheckTime(currentTime, lastTime, 2000);

  if(isDoneSection1) {
    tracer.run();
  } else {
    tracer.round();
  }
  
  ext_tsk();
}

bool CheckTime(uint32_t now, uint32_t last, uint32_t dulation) {
  if((now - last) >= dulation) {
    return true;
  } else {
    return false;
  }
}

void InitializeClock () {
  clock.reset();
  currentTime = lastTime = clock.now();
  isInitializedClock = true;
}

void main_task(intptr_t unused) {
  const uint32_t duration = 100;
  tracer.init();
  sta_cyc(TRACER_CYC); 

  if (!isInitializedClock) {
    InitializeClock();
  }
  
  while (!ev3_button_is_pressed(LEFT_BUTTON)) { 
      clock.sleep(duration);   
  }

  stp_cyc(TRACER_CYC); 
  tracer.terminate();
  ext_tsk(); 
}

